"""
Run this once after setting up the database to create the Master Admin account.

    python seed.py

It reads MASTER_ADMIN_EMAIL / MASTER_ADMIN_PASSWORD / MASTER_ADMIN_NAME from
your .env file. If a master admin already exists, this script does nothing
(safe to re-run).
"""
from campusconnect import create_app
from campusconnect.extensions import db
from campusconnect.models import User, Role

app = create_app()

with app.app_context():
    existing = User.query.filter_by(role=Role.MASTER_ADMIN).first()
    if existing:
        print(f"Master admin already exists: {existing.username} <{existing.email}>")
    else:
        email = app.config["MASTER_ADMIN_EMAIL"].strip().lower()
        password = app.config["MASTER_ADMIN_PASSWORD"]
        name = app.config["MASTER_ADMIN_NAME"]

        master = User(
            full_name=name,
            email=email,
            username="Adhiban",
            role=Role.MASTER_ADMIN,
        )
        master.set_password(password)
        db.session.add(master)
        db.session.commit()

        print("Master admin account created:")
        print(f"  username: Adhiban")
        print(f"  email:    {email}")
        print(f"  password: (whatever you set in .env — change it after first login)")
