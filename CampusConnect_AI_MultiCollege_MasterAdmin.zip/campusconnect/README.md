# CampusConnect AI — Setup & Run Guide

This project is scoped to **local development only**: SQLite storage,
Flask's built-in dev server, running on your own computer at
`http://127.0.0.1:5000`.

## Quick Start (Windows, no typing required)

1. Make sure Python is installed (see Prerequisites below).
2. Double-click **`setup.bat`**. Follow what it says on screen — it will
   pause once and ask you to edit the `.env` file it creates (just set your
   own `SECRET_KEY` and `MASTER_ADMIN_PASSWORD` in Notepad, save, close).
3. Once it says "Setup complete!", double-click **`run.bat`**.
4. Open `http://127.0.0.1:5000` in your browser.
5. Log in with username `masteradmin` and the password you set in `.env`.

From then on, every time you want to use the app: just double-click
`run.bat` again. You only need `setup.bat` once.

---

## Manual Setup (typing commands yourself, any OS)

### 1. Prerequisites
- Python 3.10+ installed

### 2. Get the project onto your machine
Unzip the project folder anywhere, e.g. `C:\campusconnect` or `~/campusconnect`.

### 3. Create a virtual environment
Open a terminal **inside the project folder** and run:
```bash
python -m venv venv
```
Activate it:
- Windows: `venv\Scripts\activate`
- Mac/Linux: `source venv/bin/activate`

You'll see `(venv)` appear at the start of your terminal prompt when it's active.

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

### 5. Set up environment variables
Copy the example env file:
- Windows: `copy .env.example .env`
- Mac/Linux: `cp .env.example .env`

Open `.env` and change `SECRET_KEY` to any random string, and set your own
`MASTER_ADMIN_PASSWORD`.

### 6. Create the database + Master Admin account
```bash
python seed.py
```
This creates `campusconnect.db` (a SQLite file) and prints your Master Admin
login (username: `masteradmin`, password: whatever you set in `.env`).

### 7. Run the app
```bash
python run.py
```
You'll see `Running on http://127.0.0.1:5000`. Open that URL in your browser.

### 8. Log in
- **Master Admin**: username `masteradmin`, password from your `.env`.
- **Students**: click "Create an account" on the login page to self-register.
- **Admin/Staff accounts**: log in as Master Admin → "Manage Admins" → create
  an admin account and tick which permissions they get.

### 9. Re-running later
Once set up, you only ever need:
```bash
venv\Scripts\activate   # (or: source venv/bin/activate  on Mac/Linux)
python run.py
```

---

---

## Using it on your phone

Your phone and computer must be on the **same Wi-Fi network**.

1. Double-click `run.bat` (or run `python run.py`) as usual.
2. Look at the black window — it now shows two addresses:
   ```
   On THIS computer, open:      http://127.0.0.1:5000
   On your PHONE (same Wi-Fi):  http://192.168.x.x:5000
   ```
3. On your phone, open its web browser and type in that second address
   (the one with numbers, not `127.0.0.1`).
4. Log in as normal.

**Make it look like an app icon:** once it's open on your phone browser,
use the browser menu → "Add to Home Screen". This puts an icon on your
phone that opens it directly, like an app.

**If the phone can't connect:**
- Make sure both devices are on the same Wi-Fi (not phone data / hotspot).
- Windows may ask "Allow this app through the firewall?" the first time
  you run it — click **Allow**.
- If the address shown looks wrong, open Command Prompt and type
  `ipconfig`, then look for "IPv4 Address" under your Wi-Fi adapter and
  use that number instead.
- This only works on your own Wi-Fi — it will not work over mobile data
  or from outside your network. That would need putting the app on a
  real server, which is a separate, bigger step.

## Notes
- Uploaded photos are saved to `static/uploads/` locally.
- To reset all data: stop the app, delete `campusconnect.db`, then run
  `python seed.py` again.
- This build is intentionally dev-only. It is not configured for production
  hosting (no HTTPS, no production database, no production WSGI server).

## Live GPS & SOS monitoring
- Students can explicitly enable device GPS from the student dashboard. The browser must grant location permission.
- Latest GPS coordinates are sent to `/sos/api/location` and shown to authorized SOS admins via `/sos/api/monitor`.
- Admin dashboards poll every 3 seconds for active SOS alerts and recent GPS updates.
- SOS alerts use a red pulsing alert, browser notification (when permitted), vibration where supported, and a Web Audio alarm after the admin enables sound.
- Browser security may block sound until the admin interacts with the page; this is a browser limitation. A native/PWA push system is needed for guaranteed alerts when the browser is closed.


## Multi-college / institution mode

CampusConnect now supports tenant isolation across multiple institutions.

- **Master Admin:** global access to all colleges, admins, students, complaints, SOS, GPS, announcements and analytics.
- **College Admin:** restricted to the college assigned to that admin.
- **Student:** restricted to their own college's announcements, Lost & Found and safety data; personal complaints remain private to the student and authorized admins.
- **College management:** Master Admin → **Colleges** → **+ Add College**. Each college card shows its admins/students and provides **+ Add admin**.
- **Student registration:** students must enter/select their college code.
- **Admin creation:** Master Admin assigns each admin to an active college.
- **SOS isolation:** an admin receives only SOS/GPS events from their own college; the Master Admin receives all institutions' alerts.
- **SOS popup:** includes student name/ID, college, department, phone (if provided), location, GPS coordinates, message and timestamp. The dashboard can play a repeating siren after the browser sound is enabled.
- **Important browser limitation:** browsers require a user interaction before Web Audio can play automatically, so each admin device should click **Enable Emergency Sound** once. Actual loudness is still controlled by the device/OS volume.
- Existing single-campus databases are migrated to a `MAIN` / `Main Campus` institution automatically.
