from flask import Blueprint

lostfound_bp = Blueprint("lostfound", __name__, url_prefix="/lostfound")

from campusconnect.lostfound import routes  # noqa: E402,F401
