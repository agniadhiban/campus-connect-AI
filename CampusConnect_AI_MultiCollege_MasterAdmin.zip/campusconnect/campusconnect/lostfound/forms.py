from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, SubmitField
from wtforms.validators import DataRequired, Length, Optional


class LostFoundForm(FlaskForm):
    item_type = SelectField("Type", choices=[("lost", "I lost this"), ("found", "I found this")],
                             validators=[DataRequired()])
    item_name = StringField("Item name", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Description", validators=[Length(max=1000)])
    location = StringField("Location seen / lost", validators=[Length(max=150)])
    contact_info = StringField("Contact info to show (optional — defaults to your profile)",
                                validators=[Optional(), Length(max=150)])
    photo = FileField("Photo (optional)", validators=[FileAllowed(["jpg", "jpeg", "png"], "Images only.")])
    submit = SubmitField("Post item")
