import os
import uuid

from flask import render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from campusconnect.lostfound import lostfound_bp
from campusconnect.lostfound.forms import LostFoundForm
from campusconnect.extensions import db
from campusconnect.models import LostFoundItem, now_utc
from campusconnect.decorators import permission_required, college_scope


def _save_photo(file_storage):
    if not file_storage or not file_storage.filename:
        return None
    ext = os.path.splitext(secure_filename(file_storage.filename))[1]
    filename = f"{uuid.uuid4().hex}{ext}"
    path = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    file_storage.save(path)
    return filename


@lostfound_bp.route("/")
@login_required
def list_items():
    item_type = request.args.get("type")  # lost | found | None
    query = college_scope(LostFoundItem.query.filter_by(is_resolved=False), LostFoundItem)
    if item_type in ("lost", "found"):
        query = query.filter_by(item_type=item_type)
    items = query.order_by(LostFoundItem.created_at.desc()).all()
    return render_template("lostfound/list.html", items=items, active_filter=item_type)


@lostfound_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_item():
    form = LostFoundForm()
    if form.validate_on_submit():
        photo_filename = _save_photo(form.photo.data)
        item = LostFoundItem(
            item_type=form.item_type.data,
            item_name=form.item_name.data.strip(),
            description=form.description.data.strip() if form.description.data else None,
            location=form.location.data.strip() if form.location.data else None,
            contact_info=form.contact_info.data.strip() if form.contact_info.data else None,
            photo_filename=photo_filename,
            reported_by_id=current_user.id,
            college_id=current_user.college_id,
        )
        db.session.add(item)
        db.session.commit()
        flash("Posted to Lost & Found.", "success")
        return redirect(url_for("lostfound.list_items"))
    return render_template("lostfound/new.html", form=form)


@lostfound_bp.route("/<public_id>")
@login_required
def view_item(public_id):
    item = LostFoundItem.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.is_master_admin and item.college_id != current_user.college_id:
        abort(403)
    return render_template("lostfound/detail.html", item=item)


@lostfound_bp.route("/<public_id>/resolve", methods=["POST"])
@login_required
def resolve_item(public_id):
    item = LostFoundItem.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.is_master_admin and item.college_id != current_user.college_id:
        abort(403)
    is_owner = item.reported_by_id == current_user.id
    is_staff = current_user.is_staff and current_user.has_permission("manage_lostfound")
    if not (is_owner or is_staff):
        abort(403)

    item.is_resolved = True
    item.resolved_at = now_utc()
    db.session.commit()
    flash("Marked as resolved / returned.", "success")
    return redirect(url_for("lostfound.list_items"))
