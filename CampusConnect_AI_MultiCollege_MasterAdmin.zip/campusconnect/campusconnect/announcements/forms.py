from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length


class AnnouncementForm(FlaskForm):
    title = StringField("Title", validators=[DataRequired(), Length(max=150)])
    body = TextAreaField("Message", validators=[DataRequired(), Length(max=3000)])
    is_pinned = BooleanField("Pin to top")
    submit = SubmitField("Post announcement")


class AnonymousTipForm(FlaskForm):
    subject = StringField("Subject", validators=[DataRequired(), Length(max=150)])
    body = TextAreaField("Details", validators=[DataRequired(), Length(max=3000)])
    submit = SubmitField("Send anonymously")
