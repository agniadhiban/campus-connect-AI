from flask import render_template, redirect, url_for, flash, abort, request
from flask_login import login_required, current_user

from campusconnect.announcements import announcements_bp
from campusconnect.announcements.forms import AnnouncementForm, AnonymousTipForm
from campusconnect.extensions import db
from campusconnect.models import Announcement, AnonymousTip, College
from campusconnect.decorators import permission_required


@announcements_bp.route("/")
@login_required
def list_announcements():
    announcements = Announcement.query.order_by(
        Announcement.is_pinned.desc(), Announcement.created_at.desc()
    )
    if not current_user.is_master_admin:
        announcements = announcements.filter_by(college_id=current_user.college_id)
    announcements = announcements.all()
    return render_template("announcements/list.html", announcements=announcements)


@announcements_bp.route("/new", methods=["GET", "POST"])
@login_required
@permission_required("manage_announcements")
def new_announcement():
    form = AnnouncementForm()
    colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all()
    if form.validate_on_submit():
        target_college = current_user.college
        if current_user.is_master_admin:
            code = (request.form.get("college_code") or "").strip().upper()
            target_college = College.query.filter_by(code=code, is_active=True).first()
            if not target_college:
                flash("Select a valid target college.", "danger")
                return render_template("announcements/new.html", form=form, colleges=colleges)
        announcement = Announcement(
            title=form.title.data.strip(),
            body=form.body.data.strip(),
            is_pinned=form.is_pinned.data,
            posted_by_id=current_user.id,
            college_id=target_college.id,
        )
        db.session.add(announcement)
        db.session.commit()
        flash("Announcement posted.", "success")
        return redirect(url_for("announcements.list_announcements"))
    return render_template("announcements/new.html", form=form, colleges=colleges)


@announcements_bp.route("/tip", methods=["GET", "POST"])
@login_required
def new_tip():
    """Fully anonymous — we don't store who submitted it, by design."""
    if not current_user.is_student:
        return redirect(url_for("main.dashboard"))

    form = AnonymousTipForm()
    if form.validate_on_submit():
        tip = AnonymousTip(subject=form.subject.data.strip(), body=form.body.data.strip(),
                           college_id=current_user.college_id)
        db.session.add(tip)
        db.session.commit()
        flash("Sent anonymously. Thank you for speaking up.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("announcements/new_tip.html", form=form)


@announcements_bp.route("/tips")
@login_required
@permission_required("manage_announcements")
def list_tips():
    query = AnonymousTip.query.order_by(AnonymousTip.created_at.desc())
    if not current_user.is_master_admin:
        query = query.filter_by(college_id=current_user.college_id)
    tips = query.all()
    return render_template("announcements/tips_list.html", tips=tips)


@announcements_bp.route("/tips/<public_id>/close", methods=["POST"])
@login_required
@permission_required("manage_announcements")
def close_tip(public_id):
    tip = AnonymousTip.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.is_master_admin and tip.college_id != current_user.college_id:
        abort(403)
    tip.status = "closed"
    db.session.commit()
    flash("Tip marked closed.", "success")
    return redirect(url_for("announcements.list_tips"))
