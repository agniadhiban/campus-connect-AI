from flask import render_template, redirect, url_for
from flask_login import login_required, current_user
from sqlalchemy import func

from campusconnect.main import main_bp
from campusconnect.extensions import db
from campusconnect.models import (
    Complaint, ComplaintStatus, ComplaintPriority,
    SOSAlert, SOSStatus, StudentLocation, LostFoundItem, Announcement, User, Role,
)
from campusconnect.decorators import college_scope


@main_bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    return redirect(url_for("auth.login"))


@main_bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.is_student:
        return _student_dashboard()
    return _staff_dashboard()


def _student_dashboard():
    my_complaints = (
        Complaint.query.filter_by(reporter_id=current_user.id)
        .order_by(Complaint.created_at.desc())
        .limit(5)
        .all()
    )
    active_sos = (
        SOSAlert.query.filter_by(student_id=current_user.id)
        .filter(SOSAlert.status != SOSStatus.RESOLVED)
        .order_by(SOSAlert.created_at.desc())
        .first()
    )
    announcements_q = Announcement.query.order_by(
        Announcement.is_pinned.desc(), Announcement.created_at.desc()
    )
    announcements = announcements_q.filter_by(college_id=current_user.college_id).limit(5).all()
    recent_found_items = (
        LostFoundItem.query.filter_by(item_type="found", is_resolved=False, college_id=current_user.college_id)
        .order_by(LostFoundItem.created_at.desc())
        .limit(4)
        .all()
    )

    return render_template(
        "main/student_dashboard.html",
        my_complaints=my_complaints,
        active_sos=active_sos,
        announcements=announcements,
        recent_found_items=recent_found_items,
    )


def _staff_dashboard():
    can_see_complaints = current_user.has_permission("manage_complaints")
    can_see_sos = current_user.has_permission("manage_sos")
    can_see_lostfound = current_user.has_permission("manage_lostfound")
    can_see_analytics = current_user.has_permission("view_analytics")

    stats = {}
    priority_queue = []
    active_sos_alerts = []
    live_locations = []
    unresolved_items_count = 0

    if can_see_complaints:
        stats["open_complaints"] = college_scope(Complaint.query.filter_by(status=ComplaintStatus.OPEN), Complaint).count()
        stats["in_progress"] = college_scope(Complaint.query.filter_by(status=ComplaintStatus.IN_PROGRESS), Complaint).count()
        stats["resolved_total"] = college_scope(Complaint.query.filter_by(status=ComplaintStatus.RESOLVED), Complaint).count()
        stats["critical_open"] = college_scope(Complaint.query.filter_by(
            status=ComplaintStatus.OPEN, priority=ComplaintPriority.CRITICAL
        ), Complaint).count()

        # Priority queue: open complaints, most severe & most-reported first.
        priority_rank = {p: i for i, p in enumerate(ComplaintPriority.ORDER)}
        open_complaints = college_scope(Complaint.query.filter(
            Complaint.status.in_([ComplaintStatus.OPEN, ComplaintStatus.IN_PROGRESS])
        ), Complaint).all()
        priority_queue = sorted(
            open_complaints,
            key=lambda c: (-priority_rank.get(c.priority, 0), -c.report_count),
        )[:8]

    if can_see_sos:
        active_sos_alerts = (
            college_scope(SOSAlert.query.filter(SOSAlert.status != SOSStatus.RESOLVED), SOSAlert)
            .order_by(SOSAlert.created_at.desc())
            .all()
        )

    if can_see_sos:
        live_locations = college_scope(StudentLocation.query, StudentLocation).order_by(StudentLocation.updated_at.desc()).all()

    if can_see_lostfound:
        unresolved_items_count = college_scope(LostFoundItem.query.filter_by(is_resolved=False), LostFoundItem).count()

    student_count = User.query.filter_by(role=Role.STUDENT).count() if current_user.is_master_admin else None
    admin_count = User.query.filter_by(role=Role.ADMIN).count() if current_user.is_master_admin else None

    return render_template(
        "main/staff_dashboard.html",
        stats=stats,
        priority_queue=priority_queue,
        active_sos_alerts=active_sos_alerts,
        live_locations=live_locations,
        unresolved_items_count=unresolved_items_count,
        can_see_complaints=can_see_complaints,
        can_see_sos=can_see_sos,
        can_see_lostfound=can_see_lostfound,
        can_see_analytics=can_see_analytics,
        student_count=student_count,
        admin_count=admin_count,
    )


@main_bp.route("/analytics")
@login_required
def analytics():
    if not current_user.has_permission("view_analytics"):
        return redirect(url_for("main.dashboard"))

    by_category = (
        college_scope(db.session.query(Complaint.category, func.count(Complaint.id)), Complaint)
        .group_by(Complaint.category)
        .all()
    )
    by_status = (
        college_scope(db.session.query(Complaint.status, func.count(Complaint.id)), Complaint)
        .group_by(Complaint.status)
        .all()
    )
    by_priority = (
        college_scope(db.session.query(Complaint.priority, func.count(Complaint.id)), Complaint)
        .group_by(Complaint.priority)
        .all()
    )
    top_locations = (
        college_scope(db.session.query(Complaint.location, func.count(Complaint.id).label("cnt")), Complaint)
        .group_by(Complaint.location)
        .order_by(func.count(Complaint.id).desc())
        .limit(5)
        .all()
    )

    return render_template(
        "main/analytics.html",
        by_category=by_category,
        by_status=by_status,
        by_priority=by_priority,
        top_locations=top_locations,
    )
