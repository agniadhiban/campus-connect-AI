from flask import render_template, redirect, url_for, flash, abort, request
from flask_login import login_required, current_user

from campusconnect.admin import admin_bp
from campusconnect.admin.forms import CreateAdminForm, EditPermissionsForm
from campusconnect.extensions import db
from campusconnect.models import User, Role, College
from campusconnect.decorators import roles_required


@admin_bp.route("/staff")
@login_required
@roles_required(Role.MASTER_ADMIN)
def list_staff():
    college_id = request.args.get("college_id", type=int)
    query = User.query.filter_by(role=Role.ADMIN)
    if college_id:
        query = query.filter_by(college_id=college_id)
    admins = query.order_by(User.created_at.desc()).all()
    colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all()
    return render_template("admin/staff_list.html", admins=admins, colleges=colleges, selected_college_id=college_id)


@admin_bp.route("/staff/new", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def new_admin():
    form = CreateAdminForm()
    colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all()
    selected_college = request.args.get("college_id", type=int)
    if selected_college and not form.college_id.data:
        c = College.query.filter_by(id=selected_college, is_active=True).first()
        if c:
            form.college_id.data = c.code
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        college = College.query.filter_by(code=form.college_id.data.strip().upper(), is_active=True).first()
        if not college:
            flash("Select a valid active college code.", "danger")
            return render_template("admin/new_staff.html", form=form, colleges=colleges)

        username = form.username.data.strip().lower()

        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "danger")
            return render_template("admin/new_staff.html", form=form, colleges=colleges)
        if User.query.filter_by(username=username).first():
            flash("That username is taken.", "danger")
            return render_template("admin/new_staff.html", form=form, colleges=colleges)

        admin = User(
            full_name=form.full_name.data.strip(),
            email=email,
            username=username,
            role=Role.ADMIN,
            college_id=college.id,
            department=form.department.data.strip() if form.department.data else None,
            permissions=",".join(form.permissions.data),
            created_by_id=current_user.id,
        )
        admin.set_password(form.password.data)
        db.session.add(admin)
        db.session.commit()
        flash(f"Admin account created for {admin.full_name}. Share the temporary password securely.", "success")
        return redirect(url_for("admin.list_staff"))

    return render_template("admin/new_staff.html", form=form, colleges=colleges)


@admin_bp.route("/staff/<int:user_id>/permissions", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def edit_permissions(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    form = EditPermissionsForm()

    if form.validate_on_submit():
        admin.permissions = ",".join(form.permissions.data)
        db.session.commit()
        flash(f"Permissions updated for {admin.full_name}.", "success")
        return redirect(url_for("admin.list_staff"))

    form.permissions.data = (admin.permissions or "").split(",")
    return render_template("admin/edit_permissions.html", form=form, admin=admin)


@admin_bp.route("/staff/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_staff_active(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    admin.is_active_account = not admin.is_active_account
    db.session.commit()
    state = "enabled" if admin.is_active_account else "disabled"
    flash(f"{admin.full_name}'s account has been {state}.", "success")
    return redirect(url_for("admin.list_staff"))


@admin_bp.route("/staff/<int:user_id>/remove", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def remove_admin(user_id):
    admin = User.query.filter_by(id=user_id, role=Role.ADMIN).first_or_404()
    if admin.id == current_user.id:
        abort(400)
    name = admin.full_name
    db.session.delete(admin)
    db.session.commit()
    flash(f"Removed admin account for {name}.", "success")
    return redirect(url_for("admin.list_staff"))


@admin_bp.route("/colleges")
@login_required
@roles_required(Role.MASTER_ADMIN)
def list_colleges():
    colleges = College.query.order_by(College.name.asc()).all()
    return render_template("admin/colleges.html", colleges=colleges)


@admin_bp.route("/colleges/new", methods=["GET", "POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def new_college():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        code = request.form.get("code", "").strip().upper()
        city = request.form.get("city", "").strip()
        if not name or not code:
            flash("College name and code are required.", "danger")
            return render_template("admin/new_college.html")
        if College.query.filter((College.name == name) | (College.code == code)).first():
            flash("A college with that name or code already exists.", "danger")
            return render_template("admin/new_college.html")
        db.session.add(College(name=name, code=code, city=city or None))
        db.session.commit()
        flash(f"{name} added successfully.", "success")
        return redirect(url_for("admin.list_colleges"))
    return render_template("admin/new_college.html")


@admin_bp.route("/colleges/<int:college_id>/toggle", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_college(college_id):
    college = College.query.get_or_404(college_id)
    college.is_active = not college.is_active
    db.session.commit()
    flash(f"{college.name} is now {'active' if college.is_active else 'disabled'}.", "success")
    return redirect(url_for("admin.list_colleges"))


@admin_bp.route("/students")
@login_required
@roles_required(Role.MASTER_ADMIN, Role.ADMIN)
def list_students():
    if not (current_user.is_master_admin or current_user.has_permission("manage_complaints")):
        abort(403)
    query = User.query.filter_by(role=Role.STUDENT)
    if not current_user.is_master_admin:
        query = query.filter_by(college_id=current_user.college_id)
    else:
        college_id = request.args.get("college_id", type=int)
        if college_id:
            query = query.filter_by(college_id=college_id)
    students = query.order_by(User.created_at.desc()).all()
    colleges = College.query.filter_by(is_active=True).order_by(College.name.asc()).all() if current_user.is_master_admin else []
    return render_template("admin/students_list.html", students=students, colleges=colleges,
                           selected_college_id=request.args.get("college_id", type=int))


@admin_bp.route("/students/<int:user_id>/toggle-active", methods=["POST"])
@login_required
@roles_required(Role.MASTER_ADMIN)
def toggle_student_active(user_id):
    student = User.query.filter_by(id=user_id, role=Role.STUDENT).first_or_404()
    student.is_active_account = not student.is_active_account
    db.session.commit()
    state = "enabled" if student.is_active_account else "disabled"
    flash(f"{student.full_name}'s account has been {state}.", "success")
    return redirect(url_for("admin.list_students"))
