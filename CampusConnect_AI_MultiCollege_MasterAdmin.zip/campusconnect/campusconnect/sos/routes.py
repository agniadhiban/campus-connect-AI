from flask import render_template, redirect, url_for, flash, abort, jsonify, request
from flask_login import login_required, current_user

from campusconnect.sos import sos_bp
from campusconnect.sos.forms import SOSForm
from campusconnect.extensions import db
from campusconnect.models import SOSAlert, SOSStatus, StudentLocation, User, Role, now_utc
from campusconnect.decorators import permission_required, college_scope


@sos_bp.route("/new", methods=["GET", "POST"])
@login_required
def new_alert():
    if not current_user.is_student:
        abort(403)  # SOS is raised by students; staff respond to it

    form = SOSForm()
    if form.validate_on_submit():
        alert = SOSAlert(
            student_id=current_user.id,
            college_id=current_user.college_id,
            urgency=form.urgency.data,
            location_text=form.location_text.data.strip(),
            message=form.message.data.strip() if form.message.data else None,
            latitude=float(form.latitude.data) if form.latitude.data else None,
            longitude=float(form.longitude.data) if form.longitude.data else None,
        )
        db.session.add(alert)
        db.session.commit()
        flash("SOS alert sent. Campus security/admin has been notified. Stay where it's safe.", "danger")
        return redirect(url_for("main.dashboard"))

    return render_template("sos/new.html", form=form)


@sos_bp.route("/api/location", methods=["POST"])
@login_required
def update_location():
    """Receive permission-based GPS updates from a student's device."""
    if not current_user.is_student:
        abort(403)
    data = request.get_json(silent=True) or {}
    try:
        latitude = float(data.get("latitude"))
        longitude = float(data.get("longitude"))
        accuracy = float(data.get("accuracy")) if data.get("accuracy") is not None else None
        speed = float(data.get("speed")) if data.get("speed") is not None else None
        heading = float(data.get("heading")) if data.get("heading") is not None else None
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Invalid GPS data."}), 400

    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return jsonify({"ok": False, "error": "GPS coordinates out of range."}), 400

    location = StudentLocation.query.filter_by(student_id=current_user.id).first()
    if location is None:
        location = StudentLocation(student_id=current_user.id, college_id=current_user.college_id)
        db.session.add(location)
    location.latitude = latitude
    location.longitude = longitude
    location.accuracy = accuracy
    location.speed = speed
    location.heading = heading
    location.source = "device-gps"
    location.updated_at = now_utc()
    db.session.commit()
    return jsonify({"ok": True, "updated_at": location.updated_at.isoformat()})


@sos_bp.route("/api/monitor")
@login_required
@permission_required("manage_sos")
def monitor_data():
    """Compact polling endpoint for admin devices: active SOS + latest student GPS."""
    active = college_scope(
        SOSAlert.query.filter(SOSAlert.status != SOSStatus.RESOLVED), SOSAlert
    ).order_by(SOSAlert.created_at.desc()).all()
    locations = college_scope(StudentLocation.query, StudentLocation).order_by(StudentLocation.updated_at.desc()).all()
    return jsonify({
        "alerts": [{
            "public_id": a.public_id,
            "student": a.student.full_name if a.student else "Unknown student",
            "student_id": (a.student.student_id or a.student.email) if a.student else "",
            "college": a.student.college.name if a.student and a.student.college else "Unknown college",
            "department": a.student.department if a.student else "",
            "phone": a.student.phone if a.student else "",
            "urgency": a.urgency,
            "status": a.status,
            "message": a.message or "",
            "latitude": a.latitude,
            "longitude": a.longitude,
            "location_text": a.location_text or "",
            "created_at": a.created_at.isoformat() if a.created_at else None,
        } for a in active],
        "locations": [{
            "student": loc.student.full_name if loc.student else "Unknown student",
            "student_id": (loc.student.student_id or loc.student.email) if loc.student else "",
            "college": loc.student.college.name if loc.student and loc.student.college else "Unknown college",
            "department": loc.student.department if loc.student else "",
            "latitude": loc.latitude,
            "longitude": loc.longitude,
            "accuracy": loc.accuracy,
            "updated_at": loc.updated_at.isoformat() if loc.updated_at else None,
        } for loc in locations],
    })


@sos_bp.route("/")
@login_required
@permission_required("manage_sos")
def list_alerts():
    alerts = college_scope(SOSAlert.query, SOSAlert).order_by(SOSAlert.created_at.desc()).all()
    return render_template("sos/list.html", alerts=alerts)


@sos_bp.route("/<public_id>/acknowledge", methods=["POST"])
@login_required
@permission_required("manage_sos")
def acknowledge(public_id):
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.is_master_admin and alert.college_id != current_user.college_id:
        abort(403)
    alert.status = SOSStatus.ACKNOWLEDGED
    alert.handled_by_id = current_user.id
    alert.acknowledged_at = now_utc()
    db.session.commit()
    flash("Alert acknowledged.", "success")
    return redirect(url_for("sos.list_alerts"))


@sos_bp.route("/<public_id>/resolve", methods=["POST"])
@login_required
@permission_required("manage_sos")
def resolve(public_id):
    alert = SOSAlert.query.filter_by(public_id=public_id).first_or_404()
    if not current_user.is_master_admin and alert.college_id != current_user.college_id:
        abort(403)
    alert.status = SOSStatus.RESOLVED
    alert.handled_by_id = current_user.id
    alert.resolved_at = now_utc()
    db.session.commit()
    flash("Alert marked resolved.", "success")
    return redirect(url_for("sos.list_alerts"))
