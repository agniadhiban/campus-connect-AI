import os
from flask import Flask
from sqlalchemy import inspect, text

from campusconnect.config import Config
from campusconnect.extensions import db, login_manager, csrf


def create_app(config_class=Config):
    app = Flask(__name__, template_folder="../templates", static_folder="../static")
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)

    from campusconnect.models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # --- Blueprints ---
    from campusconnect.auth import auth_bp
    from campusconnect.main import main_bp
    from campusconnect.complaints import complaints_bp
    from campusconnect.lostfound import lostfound_bp
    from campusconnect.sos import sos_bp
    from campusconnect.admin import admin_bp
    from campusconnect.announcements import announcements_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(complaints_bp)
    app.register_blueprint(lostfound_bp)
    app.register_blueprint(sos_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(announcements_bp)

    # --- template globals / filters ---
    from campusconnect.models import ComplaintPriority, ComplaintStatus, Role

    @app.context_processor
    def inject_globals():
        return dict(
            ComplaintPriority=ComplaintPriority,
            ComplaintStatus=ComplaintStatus,
            Role=Role,
        )

    @app.template_filter("dt")
    def format_datetime(value, fmt="%d %b %Y, %I:%M %p"):
        if not value:
            return ""
        return value.strftime(fmt)

    # --- friendly error pages instead of raw Werkzeug/Flask error dumps ---
    from flask import render_template

    @app.errorhandler(400)
    def bad_request(e):
        return render_template("errors/400.html"), 400

    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()  # in case the error left a transaction half-done
        return render_template("errors/500.html"), 500

    with app.app_context():
        db.create_all()
        # Lightweight SQLite migration for existing development databases.
        # New installs are handled by create_all(); existing installs receive
        # the tenant columns without losing their data.
        inspector = inspect(db.engine)
        tables = set(inspector.get_table_names())
        if "users" in tables:
            cols = {c["name"] for c in inspector.get_columns("users")}
            if "college_id" not in cols:
                db.session.execute(text("ALTER TABLE users ADD COLUMN college_id INTEGER"))
        tenant_tables = ["complaints", "lost_found_items", "student_locations", "sos_alerts",
                         "announcements", "anonymous_tips"]
        for table in tenant_tables:
            if table in tables:
                cols = {c["name"] for c in inspector.get_columns(table)}
                if "college_id" not in cols:
                    db.session.execute(text(f"ALTER TABLE {table} ADD COLUMN college_id INTEGER"))
        db.session.commit()

        # Preserve an existing single-campus installation by placing all
        # non-master users/data into one default institution.
        from campusconnect.models import College, User, Role
        default_college = College.query.filter_by(code="MAIN").first()
        if default_college is None:
            default_college = College(name="Main Campus", code="MAIN", city=None)
            db.session.add(default_college)
            db.session.flush()

        # Keep the configured global Master Admin identity consistent on local
        # development copies. Password is never overwritten here.
        master = User.query.filter_by(role=Role.MASTER_ADMIN).first()
        if master:
            master.email = app.config["MASTER_ADMIN_EMAIL"].strip().lower()
            master.full_name = app.config["MASTER_ADMIN_NAME"]
            master.username = "Adhiban"

        if default_college:
            db.session.execute(text("UPDATE users SET college_id=:cid WHERE role != 'master_admin' AND college_id IS NULL"),
                                {"cid": default_college.id})
            for table, user_col in [
                ("complaints", "reporter_id"), ("lost_found_items", "reported_by_id"),
                ("student_locations", "student_id"), ("sos_alerts", "student_id"),
                ("announcements", "posted_by_id")
            ]:
                if table in tables:
                    db.session.execute(text(
                        f"UPDATE {table} SET college_id=(SELECT college_id FROM users WHERE users.id={table}.{user_col}) "
                        f"WHERE college_id IS NULL"
                    ))
            if "anonymous_tips" in tables:
                # Existing anonymous tips cannot be attributed to a college safely.
                # Assign them to MAIN only during migration.
                db.session.execute(text("UPDATE anonymous_tips SET college_id=:cid WHERE college_id IS NULL"),
                                    {"cid": default_college.id})
        db.session.commit()

    return app
