from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, TextAreaField, SelectField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length

from campusconnect.models import ComplaintCategory


CATEGORY_CHOICES = [
    (ComplaintCategory.ELECTRICAL, "Electrical"),
    (ComplaintCategory.PLUMBING, "Plumbing / Water"),
    (ComplaintCategory.WIFI_IT, "Wi-Fi / IT"),
    (ComplaintCategory.CLEANLINESS, "Cleanliness"),
    (ComplaintCategory.FURNITURE, "Furniture / Infrastructure"),
    (ComplaintCategory.SECURITY, "Security"),
    (ComplaintCategory.HOSTEL, "Hostel"),
    (ComplaintCategory.OTHER, "Other"),
]


class ComplaintForm(FlaskForm):
    title = StringField("Short title", validators=[DataRequired(), Length(max=150)])
    category = SelectField("Category", choices=CATEGORY_CHOICES, validators=[DataRequired()])
    location = StringField("Location (building / room / block)", validators=[DataRequired(), Length(max=150)])
    description = TextAreaField("Describe the issue", validators=[DataRequired(), Length(max=2000)])
    photo = FileField("Photo (optional)", validators=[FileAllowed(["jpg", "jpeg", "png"], "Images only.")])
    is_anonymous = BooleanField("Report anonymously")
    submit = SubmitField("Submit complaint")


class ComplaintUpdateForm(FlaskForm):
    status = SelectField("Status", validators=[DataRequired()])
    note = TextAreaField("Update note", validators=[DataRequired(), Length(max=2000)])
    submit = SubmitField("Save update")
