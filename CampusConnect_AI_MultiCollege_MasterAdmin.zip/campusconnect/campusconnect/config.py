import os
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
load_dotenv(os.path.join(basedir, ".env"))


class Config:
    """
    Development-only configuration.

    This app is intentionally scoped to local development: SQLite storage,
    Flask's built-in dev server, debug mode on, and no production hardening
    (no HTTPS enforcement, no production WSGI server, no secrets manager).
    Do not deploy this configuration to a public server as-is.
    """

    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    # SQLite only — this app is scoped to local development.
    SQLALCHEMY_DATABASE_URI = "sqlite:///" + os.path.join(basedir, "campusconnect.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    DEBUG = True
    TESTING = False

    # Dev-friendly session/cookie settings (no HTTPS in local dev).
    SESSION_COOKIE_SECURE = False
    REMEMBER_COOKIE_SECURE = False

    MASTER_ADMIN_EMAIL = os.environ.get("MASTER_ADMIN_EMAIL", "Agni.adhiban@gmail.com")
    MASTER_ADMIN_PASSWORD = os.environ.get("MASTER_ADMIN_PASSWORD", "ChangeMe123!")
    MASTER_ADMIN_NAME = os.environ.get("MASTER_ADMIN_NAME", "Adhiban")

    # --- Duplicate-detection / priority-escalation tuning ---
    # Two complaints are considered "the same issue" if they share a category,
    # their locations look similar enough, and their description text is similar
    # enough (see campusconnect/complaints/utils.py for the matching logic).
    DUPLICATE_TEXT_SIMILARITY_THRESHOLD = 0.55   # 0-1, higher = stricter match
    DUPLICATE_LOCATION_SIMILARITY_THRESHOLD = 0.6
    DUPLICATE_TIME_WINDOW_HOURS = 72             # only compare against recent complaints

    # Report-count thresholds that bump priority up a level.
    # 1 report = low, 2-3 = medium, 4-6 = high, 7+ = critical
    PRIORITY_THRESHOLDS = {
        "low": 1,
        "medium": 2,
        "high": 4,
        "critical": 7,
    }

    UPLOAD_FOLDER = os.path.join(basedir, "static", "uploads")
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024  # 8 MB max upload (photos for lost&found / complaints)
