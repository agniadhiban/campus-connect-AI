"""
Entry point for CampusConnect AI.

This project is scoped to local development only:
    python run.py

Runs Flask's built-in dev server on port 5000, with debug mode on.

Bound to 0.0.0.0 so other devices on the SAME Wi-Fi (like your phone) can
reach it too, using your computer's local IP address (see README.md for
how to find that IP and use the app from your phone's browser).
This does NOT make it reachable from the internet — only from your own
Wi-Fi network.
"""
from campusconnect import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
